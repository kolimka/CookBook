//
//  RowTable.swift
//  Koshelev_Kolesnikov_Boyarinov WatchKit Extension
//
//  Created by Student on 14.02.2022.
//

import WatchKit

class RowTable: NSObject {

}
