//
//  Recipes.swift
//  Koshelev_Kolesnikov_Boyarinov WatchKit Extension
//
//  Created by Student on 14.02.2022.
//

import Foundation

struct Recipes {
    var recipeName: String
    var recipeAuthor: String
    var recipeRating: Double
    var recipeText: String
    var recipeIcon: String
    var recipeImage: String
    
    static func getRecipe()->[Recipes] {
        return [
            Recipes(recipeName: <#T##String#>, recipeAuthor: <#T##String#>, recipeRating: <#T##Double#>, recipeText: <#T##String#>, recipeIcon: <#T##String#>, recipeImage: <#T##String#>)
        ]
    }
}
